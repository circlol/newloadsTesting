<#
.SYNOPSIS
    Executes a PowerShell command and handles errors with an option to suppress output.

.DESCRIPTION
    The Use-Command function is used to execute a PowerShell command and handle any errors that may occur during the execution. It provides an option to suppress the command's output if desired.

.PARAMETER Command
    Specifies the PowerShell command to be executed. This parameter is mandatory.

.PARAMETER Suppress
    If this switch is provided, the output of the executed command will be suppressed, and errors will be logged silently. Otherwise, errors will be displayed in the console.

.EXAMPLE
    Use-Command -Command "Get-Process"

    DESCRIPTION
        Executes the "Get-Process" command.

.EXAMPLE
    Use-Command -Command "Get-Service" -Suppress

    DESCRIPTION
        Executes the "Get-Service" command, but suppresses its output and logs any errors in the ErrorLog.txt file.

#>
function Use-Command() {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Command,
        [switch]$Suppress
    )
    try {
        if ($Suppress) {
            Invoke-Expression $Command -ErrorAction SilentlyContinue | Out-Null
        } else {
            Invoke-Expression $Command
        }
    } catch {
        $errorMessage = $_.Exception.Message
        $lineNumber = $_.InvocationInfo.ScriptLineNumber
        $command = $Command
        $errorType = $_.CategoryInfo.Reason
        $ErrorLog = ".\ErrorLog.txt"
        $errorString = @"
-
Time of error: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Command run was: $command
Reason for error was: $errorType
Offending line number: $lineNumber
Error Message: $errorMessage
-
"@
        Add-Content $ErrorLog $errorString
        Write-Output $_
    }
}

# SIG # Begin signature block
# MIIHAwYJKoZIhvcNAQcCoIIG9DCCBvACAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUOvVV1i1TnyCtyO/2CmVrhLJv
# /a+gggQiMIIEHjCCAwagAwIBAgIQSGGcb8+NWotO0lk12RTDYTANBgkqhkiG9w0B
# AQsFADCBlDELMAkGA1UEBhMCQ0ExCzAJBgNVBAgMAkJDMREwDwYDVQQHDAhWaWN0
# b3JpYTEeMBwGCSqGSIb3DQEJARYPY2lyY2xvbEBzaGF3LmNhMR8wHQYJKoZIhvcN
# AQkBFhBuZXdsb2Fkc0BzaGF3LmNhMRAwDgYDVQQKDAdDaXJjbG9sMRIwEAYDVQQD
# DAlOZXcgTG9hZHMwHhcNMjMwNjIxMDMyMTQ3WhcNMjQwNjIxMDM0MTQ3WjCBlDEL
# MAkGA1UEBhMCQ0ExCzAJBgNVBAgMAkJDMREwDwYDVQQHDAhWaWN0b3JpYTEeMBwG
# CSqGSIb3DQEJARYPY2lyY2xvbEBzaGF3LmNhMR8wHQYJKoZIhvcNAQkBFhBuZXds
# b2Fkc0BzaGF3LmNhMRAwDgYDVQQKDAdDaXJjbG9sMRIwEAYDVQQDDAlOZXcgTG9h
# ZHMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDQt44ecXJMhStrhxP7
# iZBc+ud0YMIoM1ckjS9fAb1hwa8b79DWgMbTLoRx5fQG6Hiq4+1hzCaR9kAFgn8y
# gHkdrv21XbaATgY+KyNk+e0QryyRbjkUtvbO7ZUNkxm1ld3epvJqs4rPGPMpnoj+
# fzbs1YjzEoq1Pd0hfc032DUfmjcay6k5kgFFoCzbrjLQoP8cyneJ8WE7muwbZVUP
# cjA1UujXDeO6O2KMJtnPkCjr+8vlGfkxc6zfdWMxXn5yCFZjKIGwiLvSlXBlGTKp
# dayNTTz8TZC96mtQhVez3WZU9MzP/gicbzXwb6gzkNsJYYTiN+gI+MwqJnSbEPNY
# krRJAgMBAAGjajBoMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcD
# AzAiBgNVHREEGzAZghd3d3cubW90aGVyY29tcHV0ZXJzLmNvbTAdBgNVHQ4EFgQU
# JkPTOiVNkHT7I4KIkYbt1sJ26HMwDQYJKoZIhvcNAQELBQADggEBAIBa7suOeJ5L
# 20Eftw4YffTpYsZHlWBrhJOJWS/kye7LtSUMpusAhLK9kQpbtHclCo7VRIutXNip
# UlMF4pVLBi3LI7hNKPnw1j0PB/4hNwjHMwlcPGvY+wcFPZbJtpwiPNeiIpfA6n8U
# ph2Z3CmdeFOBdSzKYfo77ofOuyuYsnp+272wM6nOrQEsJoqp+TWjeGiKkLZFhXgO
# b6YyAcn+ZKDJzIMoNJ0DuzRUWY4ONdwA4qwvzlOn+PHYivCkvbZUtOc39Hvr7q/h
# 4y6ftOGq7K0MH002S4rkIfuhmKodXxLch1oCzJWE51s64nCfe808LSk7D8J0QbYN
# QMT1YZwc3boxggJLMIICRwIBATCBqTCBlDELMAkGA1UEBhMCQ0ExCzAJBgNVBAgM
# AkJDMREwDwYDVQQHDAhWaWN0b3JpYTEeMBwGCSqGSIb3DQEJARYPY2lyY2xvbEBz
# aGF3LmNhMR8wHQYJKoZIhvcNAQkBFhBuZXdsb2Fkc0BzaGF3LmNhMRAwDgYDVQQK
# DAdDaXJjbG9sMRIwEAYDVQQDDAlOZXcgTG9hZHMCEEhhnG/PjVqLTtJZNdkUw2Ew
# CQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# IwYJKoZIhvcNAQkEMRYEFErjLTYwwc7eaAKYaAisDtIqqXVDMA0GCSqGSIb3DQEB
# AQUABIIBABlpmW7dTwv4BSdsyf97WDmOd9k5nLBMAtwzUUSeBLy/720n0Ez3WKeN
# XU1HUyq3x+Q2pCPfHxOPTjLTn5l55W+QN3D/VDvAGhqVepEZlbAj8D/rsxfCRVta
# faW9VtZ2AgytGPkY4uW0yKISiSDtdEvpZKw0tmE06ZiXBjCD94j0NjF+nPtaH2fZ
# OWfbO5wU9EjvJ6L3MhrmsqxhFmf6L4GJ8ip6YYk+IU3UIZtlMvhinmn+sEA6Pir9
# scEJc5VUtyil89/WRsitVOUHfnJCLZCb0ytSN2ZF5CK2F45tM6XwTVGNCCfBxwu2
# klhvABR2lhkYIo2GA9fImN/1rnuA+X4=
# SIG # End signature block
